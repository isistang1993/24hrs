// ~/DAPPS/faucet_barebone/app/faucet.js
if (typeof web3 !== 'undefined') {
  web3 = new Web3(web3.currentProvider);
} else {
  // set the provider you want from Web3.providers
  web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
}
console.log("Coinbase: " + web3.eth.coinbase);

// Your deployed address changes every time you deploy.
var faucetAddress = "0xc483f7dc09df0598034c312f6eeb23b414449e05";
var faucetInstance1 = web3.eth.contract(faucetCompiled.faucetInstance.info.abiDefinition).at(faucetAddress);


function asiamile() {
var ac = document.getElementById("auid").value;
var pw = document.getElementById("apw").value;

window.location= "./asia-mile2.html";
}
function inita() {
    var txn = faucetInstance1.inita({from: web3.eth.coinbase});
}
function asiamile2() {
var fee = document.getElementById("quan1").value + document.getElementById("quan2").value + document.getElementById("quan3").value + document.getElementById("quan4").value; 
    var txn = faucetInstance1.sendWei(fee, {from: web3.eth.coinbase});
while (faucetInstance1.checkstatus.call() == 1){}
window.location= "./asia-mile2.html";
}
function returnfee(){
document.getElementById("asiamile1").innerHTML =  faucetInstance1.returnfee1.call();
}
